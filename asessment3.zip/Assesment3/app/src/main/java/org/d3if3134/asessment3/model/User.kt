package org.d3if3134.asessment3.model

data class User(
    val name: String = "",
    val email: String = "",
    val photoUrl: String = ""
)
