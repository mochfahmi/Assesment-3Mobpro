package org.d3if3134.asessment3.model

data class OpStatus(
  var status: String,
  var message: String?
)
