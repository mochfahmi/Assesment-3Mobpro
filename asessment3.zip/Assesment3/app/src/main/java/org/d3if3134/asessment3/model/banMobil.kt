package org.d3if3134.asessment3.model

data class banMobil(
    val ukuranBan: String,
    val jenisBan: String,
    val merkBan: String,
    val imageId: String,
    val id: Long,
)

